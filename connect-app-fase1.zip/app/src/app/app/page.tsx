import { Logo } from "@/components/Logo";
import { ThemeToggle } from "@/components/ThemeToggle";

export default function AppHome() {
  return (
    <main className="mx-auto max-w-2xl px-6 py-10">
      <header className="mb-8 flex items-center justify-between">
        <Logo />
        <ThemeToggle />
      </header>
      <div className="card text-center">
        <h1 className="font-display text-xl font-bold">Domovský feed</h1>
        <p className="mt-2 text-sm text-ink-500 dark:text-ink-300">
          Přihlášení funguje. Feed s příspěvky, Stories a Reels přidáme ve Fázi 2.
        </p>
      </div>
    </main>
  );
}
