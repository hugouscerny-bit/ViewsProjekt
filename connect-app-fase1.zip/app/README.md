# Connect — Fáze 1: Základ

Sociální síť + chat + seznamka. Toto je **Fáze 1** z plánu: autentizace, landing page,
věkové ověření (18+) a povolení polohy. Feed, chat, seznamka atd. přijdou v dalších fázích.

## Rychlý start (lokálně)

```bash
cp .env.example .env
# vyplňte JWT_ACCESS_SECRET a JWT_REFRESH_SECRET, např.:
# openssl rand -base64 48

docker compose up -d db          # spustí jen PostgreSQL
npm install
npx prisma migrate dev --name init
npm run dev                       # http://localhost:3000
```

## Plný běh přes Docker

```bash
docker compose up --build
```

## Struktura

- `src/app` — Next.js App Router (stránky + API routy)
- `src/lib` — auth, prisma klient, validace, rate limiting
- `prisma/schema.prisma` — databázové schéma pro celou aplikaci (i budoucí fáze)
- `server/socket-server.ts` — realtime server (Socket.io), základ pro Fázi 3
- `docker-compose.yml` — app + PostgreSQL + socket server

## Co je hotové

- Landing page (dark/light mode, glassmorphism, responzivní)
- Registrace/přihlášení emailem + JWT (access + refresh token, httpOnly cookies)
- Ověření emailu
- Ověření věku 18+ se souhlasem (gate před `/dating`)
- Žádost o polohu
- Rate limiting, bezpečnostní hlavičky, hashování hesel (bcrypt)
- Kompletní Prisma schéma pro posty, chat, seznamku, notifikace, moderaci

## Co chybí (další fáze)

- Google/Apple OAuth (potřeba vaše client ID/secret v `.env`)
- Feed, Stories, Reels, upload médií
- Realtime chat UI napojený na Socket.io server
- Swipe/matching UI
- Admin panel
- GDPR cookie lišta, PWA offline režim, push notifikace
