"use client";

import { useEffect, useState, useRef, use, useCallback } from "react";
import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, Send, Image as ImageIcon, Mic, Loader2 } from "lucide-react";
import { useSocket } from "@/lib/useSocket";
import { useCurrentUser } from "@/lib/useCurrentUser";
import type { ChatMessage, ChatUser } from "@/lib/chatTypes";

export default function ConversationPage({ params }: { params: Promise<{ id: string }> }) {
  const { id: conversationId } = use(params);
  const { user: me } = useCurrentUser();
  const { socket, connected } = useSocket();

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [otherUser, setOtherUser] = useState<ChatUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState("");
  const [otherTyping, setOtherTyping] = useState(false);
  const [otherOnline, setOtherOnline] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);
  const typingTimeout = useRef<ReturnType<typeof setTimeout>>();

  // Načtení historie zpráv + info o protistraně
  useEffect(() => {
    Promise.all([
      fetch(`/api/conversations/${conversationId}/messages`).then((r) => r.json()),
      fetch("/api/conversations").then((r) => r.json())
    ]).then(([msgData, convData]) => {
      setMessages(msgData.messages ?? []);
      const conv = convData.conversations?.find((c: { id: string }) => c.id === conversationId);
      setOtherUser(conv?.otherParticipants?.[0] ?? null);
      setLoading(false);
    });
  }, [conversationId]);

  // Napojení na socket eventy
  useEffect(() => {
    const s = socket.current;
    if (!s || !connected) return;

    s.emit("conversation:join", conversationId);

    const onNew = (msg: ChatMessage) => {
      if (msg.conversationId === conversationId) setMessages((prev) => [...prev, msg]);
    };
    const onTyping = (data: { userId: string; isTyping: boolean }) => {
      if (data.userId === otherUser?.id) setOtherTyping(data.isTyping);
    };
    const onPresence = (data: { userId: string; online: boolean }) => {
      if (data.userId === otherUser?.id) setOtherOnline(data.online);
    };

    s.on("message:new", onNew);
    s.on("typing:update", onTyping);
    s.on("presence:update", onPresence);
    s.emit("message:read", { conversationId });

    return () => {
      s.off("message:new", onNew);
      s.off("typing:update", onTyping);
      s.off("presence:update", onPresence);
    };
  }, [socket, connected, conversationId, otherUser?.id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleTyping = useCallback(() => {
    const s = socket.current;
    if (!s) return;
    s.emit("typing:start", conversationId);
    clearTimeout(typingTimeout.current);
    typingTimeout.current = setTimeout(() => s.emit("typing:stop", conversationId), 1500);
  }, [socket, conversationId]);

  function sendMessage(attachmentUrl?: string, attachmentType?: string) {
    const s = socket.current;
    if (!s || (!text.trim() && !attachmentUrl)) return;
    s.emit("message:send", { conversationId, text: text.trim() || undefined, attachmentUrl, attachmentType });
    setText("");
  }

  async function handleFileUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const formData = new FormData();
    formData.append("file", file);
    const res = await fetch("/api/upload", { method: "POST", body: formData });
    const data = await res.json();
    if (res.ok) {
      const type = file.type.startsWith("video") ? "video" : file.type.startsWith("audio") ? "voice" : "image";
      sendMessage(data.url, type);
    }
  }

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center"><Loader2 className="animate-spin text-turquoise-500" /></div>;
  }

  return (
    <div className="flex h-screen flex-col">
      <header className="glass flex items-center gap-3 px-4 py-3">
        <Link href="/chat" className="text-ink-500"><ArrowLeft size={20} /></Link>
        {otherUser && (
          <>
            <div className="relative h-9 w-9 overflow-hidden rounded-full bg-turquoise-500/20">
              {otherUser.avatarUrl && <Image src={otherUser.avatarUrl} alt="" width={36} height={36} className="h-full w-full object-cover" />}
              {otherOnline && <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full border-2 border-white bg-green-500 dark:border-ink-950" />}
            </div>
            <div>
              <p className="text-sm font-semibold">{otherUser.displayName}</p>
              <p className="text-xs text-ink-400">{otherTyping ? "píše…" : otherOnline ? "online" : ""}</p>
            </div>
          </>
        )}
      </header>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-2">
        {messages.map((msg) => {
          const isMine = msg.senderId === me?.id;
          return (
            <div key={msg.id} className={`flex ${isMine ? "justify-end" : "justify-start"}`}>
              <div
                className={`max-w-[75%] rounded-2xl px-4 py-2 text-sm ${
                  isMine ? "bg-turquoise-500 text-white" : "glass"
                }`}
              >
                {msg.attachmentUrl && msg.attachmentType === "image" && (
                  <Image src={msg.attachmentUrl} alt="" width={200} height={200} className="mb-1 rounded-xl object-cover" />
                )}
                {msg.attachmentUrl && msg.attachmentType === "video" && (
                  <video src={msg.attachmentUrl} controls className="mb-1 max-h-48 rounded-xl" />
                )}
                {msg.attachmentUrl && msg.attachmentType === "voice" && (
                  <audio src={msg.attachmentUrl} controls className="mb-1" />
                )}
                {msg.text && <p>{msg.text}</p>}
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      <div className="glass flex items-center gap-2 p-3">
        <label className="cursor-pointer text-turquoise-500">
          <ImageIcon size={22} />
          <input type="file" accept="image/*,video/*,audio/*" className="hidden" onChange={handleFileUpload} />
        </label>
        <input
          className="input-field flex-1"
          placeholder="Napište zprávu…"
          value={text}
          onChange={(e) => { setText(e.target.value); handleTyping(); }}
          onKeyDown={(e) => e.key === "Enter" && sendMessage()}
        />
        <button onClick={() => sendMessage()} className="btn-primary !px-3 !py-3" aria-label="Odeslat">
          <Send size={18} />
        </button>
      </div>
    </div>
  );
}
