"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Loader2, MessageCircle } from "lucide-react";
import { AppNav } from "@/components/AppNav";
import { formatDistanceToNow } from "date-fns";
import { cs } from "date-fns/locale";
import type { ConversationSummary } from "@/lib/chatTypes";

export default function ChatHome() {
  const [conversations, setConversations] = useState<ConversationSummary[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/conversations")
      .then((res) => res.json())
      .then((data) => setConversations(data.conversations ?? []))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="flex flex-col-reverse sm:flex-row">
      <AppNav />
      <main className="mx-auto w-full max-w-2xl px-4 pb-24 pt-8 sm:pb-10">
        <h1 className="font-display text-xl font-bold">Zprávy</h1>

        {loading ? (
          <div className="flex justify-center py-12"><Loader2 className="animate-spin text-turquoise-500" /></div>
        ) : conversations.length === 0 ? (
          <div className="card mt-6 flex flex-col items-center gap-2 py-10 text-center text-sm text-ink-500 dark:text-ink-300">
            <MessageCircle className="text-turquoise-400" size={32} />
            Zatím žádné konverzace. Napište někomu z jeho profilu.
          </div>
        ) : (
          <ul className="mt-6 space-y-2">
            {conversations.map((c) => {
              const other = c.otherParticipants[0];
              if (!other) return null;
              return (
                <li key={c.id}>
                  <Link href={`/chat/${c.id}`} className="card flex items-center gap-3 !p-3 transition-transform hover:-translate-y-0.5">
                    <div className="h-12 w-12 shrink-0 overflow-hidden rounded-full bg-turquoise-500/20">
                      {other.avatarUrl && <Image src={other.avatarUrl} alt={other.displayName} width={48} height={48} className="h-full w-full object-cover" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-semibold">{other.displayName}</p>
                      <p className="truncate text-sm text-ink-500 dark:text-ink-300">
                        {c.lastMessage?.text ?? (c.lastMessage ? "📎 Příloha" : "Zatím žádné zprávy")}
                      </p>
                    </div>
                    {c.lastMessage && (
                      <span className="shrink-0 text-xs text-ink-400">
                        {formatDistanceToNow(new Date(c.lastMessage.createdAt), { locale: cs, addSuffix: false })}
                      </span>
                    )}
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </main>
    </div>
  );
}
