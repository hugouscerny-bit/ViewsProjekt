import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { verifyAccessToken } from "@/lib/auth";

export async function GET() {
  const token = cookies().get("access_token")?.value;
  if (!token || !verifyAccessToken(token)) {
    return NextResponse.json({ error: "Nejste přihlášeni." }, { status: 401 });
  }
  // Token se posílá pouze přes HTTPS a používá se výhradně pro handshake Socket.io.
  return NextResponse.json({ token });
}
