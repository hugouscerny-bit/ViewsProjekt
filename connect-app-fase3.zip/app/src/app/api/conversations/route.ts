import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

// GET /api/conversations — seznam konverzací přihlášeného uživatele
export async function GET() {
  const auth = getCurrentUser();
  if (!auth) return NextResponse.json({ error: "Nejste přihlášeni." }, { status: 401 });

  const conversations = await prisma.conversation.findMany({
    where: { participants: { some: { userId: auth.userId } } },
    include: {
      participants: { include: { user: { select: { id: true, username: true, displayName: true, avatarUrl: true } } } },
      messages: { orderBy: { createdAt: "desc" }, take: 1 }
    }
  });

  // Seřadíme podle poslední zprávy (Prisma neumí orderBy na vnořené agregaci napříč vztahy přímo)
  const sorted = conversations.sort((a, b) => {
    const aTime = a.messages[0]?.createdAt?.getTime() ?? 0;
    const bTime = b.messages[0]?.createdAt?.getTime() ?? 0;
    return bTime - aTime;
  });

  const result = sorted.map((c) => ({
    id: c.id,
    isGroup: c.isGroup,
    otherParticipants: c.participants.filter((p) => p.userId !== auth.userId).map((p) => p.user),
    lastMessage: c.messages[0] ?? null
  }));

  return NextResponse.json({ conversations: result });
}

const startSchema = z.object({ userId: z.string() });

// POST /api/conversations — najde nebo vytvoří 1:1 konverzaci s daným uživatelem
export async function POST(req: NextRequest) {
  const auth = getCurrentUser();
  if (!auth) return NextResponse.json({ error: "Nejste přihlášeni." }, { status: 401 });

  const parsed = startSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Neplatná data." }, { status: 400 });

  const { userId: targetId } = parsed.data;
  if (targetId === auth.userId) return NextResponse.json({ error: "Nelze napsat sám sobě." }, { status: 400 });

  const isBlocked = await prisma.block.findFirst({
    where: {
      OR: [
        { blockerId: auth.userId, blockedId: targetId },
        { blockerId: targetId, blockedId: auth.userId }
      ]
    }
  });
  if (isBlocked) return NextResponse.json({ error: "Komunikace s tímto uživatelem není možná." }, { status: 403 });

  // Najdeme existující 1:1 konverzaci mezi oběma uživateli
  const existing = await prisma.conversation.findFirst({
    where: {
      isGroup: false,
      AND: [
        { participants: { some: { userId: auth.userId } } },
        { participants: { some: { userId: targetId } } }
      ]
    }
  });

  if (existing) return NextResponse.json({ conversationId: existing.id });

  const conversation = await prisma.conversation.create({
    data: {
      isGroup: false,
      participants: { create: [{ userId: auth.userId }, { userId: targetId }] }
    }
  });

  return NextResponse.json({ conversationId: conversation.id }, { status: 201 });
}
