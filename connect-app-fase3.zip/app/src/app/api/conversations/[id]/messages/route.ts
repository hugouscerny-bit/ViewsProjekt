import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

async function assertParticipant(conversationId: string, userId: string) {
  return prisma.conversationParticipant.findUnique({
    where: { conversationId_userId: { conversationId, userId } }
  });
}

// GET /api/conversations/:id/messages?cursor=<id> — historie zpráv (od nejnovější)
export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = getCurrentUser();
  if (!auth) return NextResponse.json({ error: "Nejste přihlášeni." }, { status: 401 });

  const participant = await assertParticipant(params.id, auth.userId);
  if (!participant) return NextResponse.json({ error: "Nemáte přístup k této konverzaci." }, { status: 403 });

  const cursor = req.nextUrl.searchParams.get("cursor");
  const messages = await prisma.message.findMany({
    where: { conversationId: params.id },
    orderBy: { createdAt: "desc" },
    take: 30,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    include: { sender: { select: { id: true, username: true, displayName: true, avatarUrl: true } } }
  });

  return NextResponse.json({ messages: messages.reverse(), nextCursor: messages.length === 30 ? messages[0]?.id : null });
}
