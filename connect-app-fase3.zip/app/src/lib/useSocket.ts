"use client";

import { useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";

const SOCKET_URL = process.env.NEXT_PUBLIC_SOCKET_URL ?? "http://localhost:4000";

export function useSocket() {
  const socketRef = useRef<Socket | null>(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    let active = true;

    async function connect() {
      const res = await fetch("/api/auth/socket-token");
      if (!res.ok || !active) return;
      const { token } = await res.json();

      const socket = io(SOCKET_URL, { auth: { token } });
      socket.on("connect", () => setConnected(true));
      socket.on("disconnect", () => setConnected(false));
      socketRef.current = socket;
    }

    connect();
    return () => {
      active = false;
      socketRef.current?.disconnect();
    };
  }, []);

  return { socket: socketRef, connected };
}
