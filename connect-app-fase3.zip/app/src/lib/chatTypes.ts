export interface ChatUser {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
}

export interface ChatMessage {
  id: string;
  conversationId: string;
  senderId: string;
  text: string | null;
  attachmentUrl: string | null;
  attachmentType: string | null;
  isRead: boolean;
  createdAt: string;
  sender?: ChatUser;
}

export interface ConversationSummary {
  id: string;
  isGroup: boolean;
  otherParticipants: ChatUser[];
  lastMessage: ChatMessage | null;
}
