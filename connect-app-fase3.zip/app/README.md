# Connect — Fáze 1: Základ

Sociální síť + chat + seznamka. Toto je **Fáze 1** z plánu: autentizace, landing page,
věkové ověření (18+) a povolení polohy. Feed, chat, seznamka atd. přijdou v dalších fázích.

## Rychlý start (lokálně)

```bash
cp .env.example .env
# vyplňte JWT_ACCESS_SECRET a JWT_REFRESH_SECRET, např.:
# openssl rand -base64 48

docker compose up -d db          # spustí jen PostgreSQL
npm install
npx prisma migrate dev --name init
npm run dev                       # http://localhost:3000
```

## Plný běh přes Docker

```bash
docker compose up --build
```

## Struktura

- `src/app` — Next.js App Router (stránky + API routy)
- `src/lib` — auth, prisma klient, validace, rate limiting
- `prisma/schema.prisma` — databázové schéma pro celou aplikaci (i budoucí fáze)
- `server/socket-server.ts` — realtime server (Socket.io), základ pro Fázi 3
- `docker-compose.yml` — app + PostgreSQL + socket server

## Co je hotové

- Landing page (dark/light mode, glassmorphism, responzivní)
- Registrace/přihlášení emailem + JWT (access + refresh token, httpOnly cookies)
- Ověření emailu
- Ověření věku 18+ se souhlasem (gate před `/dating`)
- Žádost o polohu
- Rate limiting, bezpečnostní hlavičky, hashování hesel (bcrypt)
- Kompletní Prisma schéma pro posty, chat, seznamku, notifikace, moderaci
- **Fáze 2:** Feed s infinite scrollem, vytváření příspěvků (text/foto/video), lajky,
  komentáře (i vlákna), sledování uživatelů, veřejný profil, upload médií (lokálně nebo S3)
- **Fáze 3:** Realtime chat — seznam konverzací, 1:1 zprávy, foto/video/hlasové přílohy,
  indikátor psaní, online stav, potvrzení přečtení (napojeno na `server/socket-server.ts`)

## Co chybí (další fáze)

- Google/Apple OAuth (potřeba vaše client ID/secret v `.env`)
- Stories, Reels feed, hashtag/trendy vyhledávání
- Swipe/matching UI (seznamka)
- Admin panel
- GDPR cookie lišta, PWA offline režim, push notifikace

## Spuštění realtime chatu lokálně

Socket.io server běží odděleně od Next.js:

```bash
npx tsx server/socket-server.ts   # http://localhost:4000
```
