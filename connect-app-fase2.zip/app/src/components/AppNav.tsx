"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Search, Heart, MessageCircle, User } from "lucide-react";
import { clsx } from "clsx";

const NAV_ITEMS = [
  { href: "/app", icon: Home, label: "Domů" },
  { href: "/search", icon: Search, label: "Hledat" },
  { href: "/dating", icon: Heart, label: "Seznamka" },
  { href: "/chat", icon: MessageCircle, label: "Zprávy" },
  { href: "/profile/me", icon: User, label: "Profil" }
];

export function AppNav() {
  const pathname = usePathname();

  return (
    <nav className="fixed inset-x-0 bottom-0 z-20 glass sm:sticky sm:top-0 sm:h-screen sm:w-20 sm:border-r sm:border-t-0">
      <ul className="flex justify-around p-2 sm:flex-col sm:items-center sm:gap-2 sm:pt-6">
        {NAV_ITEMS.map(({ href, icon: Icon, label }) => {
          const active = pathname === href || (href !== "/app" && pathname.startsWith(href));
          return (
            <li key={href}>
              <Link
                href={href}
                aria-label={label}
                className={clsx(
                  "flex flex-col items-center gap-0.5 rounded-xl px-3 py-2 text-xs transition-colors",
                  active ? "text-turquoise-500" : "text-ink-400 hover:text-turquoise-500"
                )}
              >
                <Icon size={22} className={active ? "fill-turquoise-500/20" : ""} />
                <span className="sm:hidden">{label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
