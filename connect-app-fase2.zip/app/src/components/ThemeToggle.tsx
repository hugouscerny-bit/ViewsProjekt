"use client";

import { useTheme } from "next-themes";
import { useEffect, useState } from "react";
import { Moon, Sun } from "lucide-react";

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);

  // Zabraňuje hydration mismatch mezi serverem a klientem
  useEffect(() => setMounted(true), []);
  if (!mounted) return <div className="h-10 w-10" />;

  const isDark = theme === "dark";

  return (
    <button
      onClick={() => setTheme(isDark ? "light" : "dark")}
      aria-label={isDark ? "Přepnout na světlý režim" : "Přepnout na tmavý režim"}
      className="flex h-10 w-10 items-center justify-center rounded-full glass transition-transform hover:scale-105 active:scale-95"
    >
      {isDark ? <Sun size={18} className="text-turquoise-300" /> : <Moon size={18} className="text-turquoise-600" />}
    </button>
  );
}
