import { clsx } from "clsx";

export function Logo({ className, showText = true }: { className?: string; showText?: boolean }) {
  return (
    <div className={clsx("flex items-center gap-2", className)}>
      <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="logoGrad" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
            <stop stopColor="#3dc9c8" />
            <stop offset="1" stopColor="#128b8c" />
          </linearGradient>
        </defs>
        <circle cx="16" cy="16" r="16" fill="url(#logoGrad)" />
        <path
          d="M11 16c0-2.76 2.24-5 5-5 1.5 0 2.84.66 3.76 1.71M21 16c0 2.76-2.24 5-5 5-1.5 0-2.84-.66-3.76-1.71"
          stroke="white"
          strokeWidth="2"
          strokeLinecap="round"
        />
      </svg>
      {showText && <span className="font-display text-xl font-extrabold tracking-tight">Connect</span>}
    </div>
  );
}
