"use client";

import { useState, useRef } from "react";
import { Image as ImageIcon, X, Loader2 } from "lucide-react";
import type { FeedPost } from "@/lib/types";

export function CreatePost({ onCreated }: { onCreated: (post: FeedPost) => void }) {
  const [caption, setCaption] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const selected = e.target.files?.[0];
    if (!selected) return;
    setFile(selected);
    setPreview(URL.createObjectURL(selected));
  }

  function clearFile() {
    setFile(null);
    setPreview(null);
    if (inputRef.current) inputRef.current.value = "";
  }

  async function handleSubmit() {
    if (!caption.trim() && !file) return;
    setSubmitting(true);
    setError(null);

    try {
      let mediaUrls: string[] = [];
      let mediaType: "image" | "video" | undefined;

      if (file) {
        const formData = new FormData();
        formData.append("file", file);
        const uploadRes = await fetch("/api/upload", { method: "POST", body: formData });
        const uploadData = await uploadRes.json();
        if (!uploadRes.ok) throw new Error(uploadData.error ?? "Nahrání souboru selhalo.");
        mediaUrls = [uploadData.url];
        mediaType = file.type.startsWith("video") ? "video" : "image";
      }

      const res = await fetch("/api/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ caption, mediaUrls, mediaType })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Vytvoření příspěvku selhalo.");

      onCreated(data.post);
      setCaption("");
      clearFile();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Něco se pokazilo.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="card">
      <textarea
        placeholder="Co se právě děje?"
        className="input-field min-h-[80px] resize-none"
        value={caption}
        onChange={(e) => setCaption(e.target.value)}
        maxLength={2200}
      />

      {preview && (
        <div className="relative mt-3 inline-block">
          {file?.type.startsWith("video") ? (
            <video src={preview} className="max-h-56 rounded-xl" controls />
          ) : (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={preview} alt="Náhled" className="max-h-56 rounded-xl object-cover" />
          )}
          <button onClick={clearFile} className="absolute -right-2 -top-2 rounded-full bg-ink-900 p-1 text-white">
            <X size={14} />
          </button>
        </div>
      )}

      {error && <p className="mt-2 text-sm text-red-500">{error}</p>}

      <div className="mt-3 flex items-center justify-between">
        <label className="cursor-pointer text-turquoise-500 hover:text-turquoise-600">
          <ImageIcon size={22} />
          <input ref={inputRef} type="file" accept="image/*,video/*" className="hidden" onChange={handleFileChange} />
        </label>
        <button onClick={handleSubmit} disabled={submitting || (!caption.trim() && !file)} className="btn-primary">
          {submitting ? <Loader2 size={18} className="animate-spin" /> : "Přidat příspěvek"}
        </button>
      </div>
    </div>
  );
}
