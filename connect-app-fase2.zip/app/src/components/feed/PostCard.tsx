"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Heart, MessageCircle, Share2, BadgeCheck, MoreHorizontal } from "lucide-react";
import { clsx } from "clsx";
import type { FeedPost } from "@/lib/types";

export function PostCard({ post }: { post: FeedPost }) {
  const [liked, setLiked] = useState(post.likedByMe);
  const [likeCount, setLikeCount] = useState(post._count.likes);
  const [busy, setBusy] = useState(false);

  async function toggleLike() {
    if (busy) return;
    setBusy(true);
    const wasLiked = liked;
    // Optimistická aktualizace UI
    setLiked(!wasLiked);
    setLikeCount((c) => c + (wasLiked ? -1 : 1));
    try {
      const res = await fetch(`/api/posts/${post.id}/like`, { method: wasLiked ? "DELETE" : "POST" });
      if (!res.ok) throw new Error();
      const data = await res.json();
      setLiked(data.liked);
      setLikeCount(data.count);
    } catch {
      // Vrátíme zpět při chybě
      setLiked(wasLiked);
      setLikeCount((c) => c + (wasLiked ? 1 : -1));
    } finally {
      setBusy(false);
    }
  }

  return (
    <article className="card animate-fade-in !p-0 overflow-hidden">
      <header className="flex items-center justify-between p-4">
        <Link href={`/profile/${post.author.username}`} className="flex items-center gap-3">
          <div className="h-10 w-10 overflow-hidden rounded-full bg-turquoise-500/20">
            {post.author.avatarUrl && (
              <Image src={post.author.avatarUrl} alt={post.author.displayName} width={40} height={40} className="h-full w-full object-cover" />
            )}
          </div>
          <div className="flex items-center gap-1">
            <span className="text-sm font-semibold">{post.author.displayName}</span>
            {post.author.isVerifiedBadge && <BadgeCheck size={14} className="text-turquoise-500" />}
          </div>
        </Link>
        <button aria-label="Další možnosti" className="text-ink-400 hover:text-ink-600 dark:hover:text-white">
          <MoreHorizontal size={18} />
        </button>
      </header>

      {post.mediaUrls.length > 0 && (
        <div className="relative aspect-square w-full bg-ink-100 dark:bg-white/5">
          {post.mediaType === "video" ? (
            <video src={post.mediaUrls[0]} controls className="h-full w-full object-cover" />
          ) : (
            <Image src={post.mediaUrls[0]} alt="" fill className="object-cover" />
          )}
        </div>
      )}

      <div className="flex items-center gap-4 px-4 pt-3">
        <button onClick={toggleLike} aria-label="Líbí se" className="flex items-center gap-1.5 transition-transform active:scale-90">
          <Heart size={22} className={clsx(liked ? "fill-turquoise-500 text-turquoise-500" : "text-ink-600 dark:text-ink-200")} />
          <span className="text-sm">{likeCount}</span>
        </button>
        <Link href={`/post/${post.id}`} className="flex items-center gap-1.5 text-ink-600 dark:text-ink-200">
          <MessageCircle size={22} />
          <span className="text-sm">{post._count.comments}</span>
        </Link>
        <button aria-label="Sdílet" className="text-ink-600 dark:text-ink-200">
          <Share2 size={20} />
        </button>
      </div>

      {post.caption && (
        <p className="px-4 pb-4 pt-2 text-sm">
          <Link href={`/profile/${post.author.username}`} className="font-semibold">{post.author.username}</Link>{" "}
          {post.caption}
        </p>
      )}
    </article>
  );
}
