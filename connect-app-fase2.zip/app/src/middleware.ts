import { NextRequest, NextResponse } from "next/server";
import { verifyAccessToken } from "@/lib/auth";

// Trasy vyžadující přihlášení
const PROTECTED_PREFIXES = ["/app", "/dating", "/chat", "/profile", "/settings", "/admin"];
// Trasy vyžadující navíc potvrzený věk 18+ (seznamovací sekce)
const AGE_GATED_PREFIXES = ["/dating"];
// Trasy pouze pro adminy/moderátory
const ADMIN_PREFIXES = ["/admin"];

export function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  const isProtected = PROTECTED_PREFIXES.some((p) => pathname.startsWith(p));
  if (!isProtected) return NextResponse.next();

  const token = req.cookies.get("access_token")?.value;
  const payload = token ? verifyAccessToken(token) : null;

  if (!payload) {
    const loginUrl = new URL("/login", req.url);
    loginUrl.searchParams.set("redirect", pathname);
    return NextResponse.redirect(loginUrl);
  }

  if (ADMIN_PREFIXES.some((p) => pathname.startsWith(p)) && payload.role !== "ADMIN" && payload.role !== "MODERATOR") {
    return NextResponse.redirect(new URL("/app", req.url));
  }

  const isAgeGated = AGE_GATED_PREFIXES.some((p) => pathname.startsWith(p));
  if (isAgeGated) {
    const ageConfirmed = req.cookies.get("age_confirmed")?.value === "1";
    if (!ageConfirmed) {
      return NextResponse.redirect(new URL("/age-verification", req.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/app/:path*", "/dating/:path*", "/chat/:path*", "/profile/:path*", "/settings/:path*", "/admin/:path*"]
};
