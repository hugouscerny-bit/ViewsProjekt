import { z } from "zod";

export const registerSchema = z.object({
  email: z.string().email("Neplatný formát emailu"),
  username: z
    .string()
    .min(3, "Uživatelské jméno musí mít alespoň 3 znaky")
    .max(20, "Uživatelské jméno může mít max. 20 znaků")
    .regex(/^[a-zA-Z0-9_.]+$/, "Povoleny jsou pouze písmena, čísla, tečka a podtržítko"),
  password: z
    .string()
    .min(8, "Heslo musí mít alespoň 8 znaků")
    .regex(/[A-Z]/, "Heslo musí obsahovat velké písmeno")
    .regex(/[0-9]/, "Heslo musí obsahovat číslici"),
  displayName: z.string().min(1).max(50)
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1, "Zadejte heslo")
});

export const ageVerificationSchema = z.object({
  birthDate: z.string(), // ISO datum
  consent: z.literal(true, { errorMap: () => ({ message: "Souhlas je povinný" }) })
});

export type RegisterInput = z.infer<typeof registerSchema>;
export type LoginInput = z.infer<typeof loginSchema>;
