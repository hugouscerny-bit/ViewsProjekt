import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { cookies } from "next/headers";

const ACCESS_SECRET = process.env.JWT_ACCESS_SECRET as string;
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET as string;

if (!ACCESS_SECRET || !REFRESH_SECRET) {
  // Nedovolíme běh aplikace bez nastavených tajných klíčů
  throw new Error("JWT secrets nejsou nastaveny v .env (JWT_ACCESS_SECRET / JWT_REFRESH_SECRET)");
}

export interface JwtPayload {
  userId: string;
  role: "USER" | "MODERATOR" | "ADMIN";
}

// ---------- Hesla ----------

export async function hashPassword(password: string): Promise<string> {
  const salt = await bcrypt.genSalt(12);
  return bcrypt.hash(password, salt);
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

// ---------- JWT tokeny ----------

export function signAccessToken(payload: JwtPayload): string {
  return jwt.sign(payload, ACCESS_SECRET, { expiresIn: "15m" });
}

export function signRefreshToken(payload: JwtPayload): string {
  return jwt.sign(payload, REFRESH_SECRET, { expiresIn: "30d" });
}

export function verifyAccessToken(token: string): JwtPayload | null {
  try {
    return jwt.verify(token, ACCESS_SECRET) as JwtPayload;
  } catch {
    return null;
  }
}

export function verifyRefreshToken(token: string): JwtPayload | null {
  try {
    return jwt.verify(token, REFRESH_SECRET) as JwtPayload;
  } catch {
    return null;
  }
}

// ---------- Bezpečné cookies ----------

const isProd = process.env.NODE_ENV === "production";

export function setAuthCookies(accessToken: string, refreshToken: string) {
  const store = cookies();
  store.set("access_token", accessToken, {
    httpOnly: true,
    secure: isProd,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 15 // 15 minut
  });
  store.set("refresh_token", refreshToken, {
    httpOnly: true,
    secure: isProd,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30 // 30 dní
  });
}

export function clearAuthCookies() {
  const store = cookies();
  store.delete("access_token");
  store.delete("refresh_token");
}

export function getCurrentUser(): JwtPayload | null {
  const token = cookies().get("access_token")?.value;
  if (!token) return null;
  return verifyAccessToken(token);
}
