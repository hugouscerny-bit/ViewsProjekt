export interface PostAuthor {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  isVerifiedBadge: boolean;
}

export interface FeedPost {
  id: string;
  caption: string | null;
  mediaUrls: string[];
  mediaType: string | null;
  isReel: boolean;
  createdAt: string;
  author: PostAuthor;
  likedByMe: boolean;
  _count: { likes: number; comments: number };
}
