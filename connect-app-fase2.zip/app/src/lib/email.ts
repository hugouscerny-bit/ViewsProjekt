// V produkci nahraďte skutečnou integrací (Resend, SendGrid, SMTP...).
// Zde je připraveno rozhraní přes Resend SDK.

import { Resend } from "resend";

const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;
const APP_URL = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

export async function sendVerificationEmail(email: string, token: string) {
  const verifyUrl = `${APP_URL}/api/auth/verify-email?token=${token}`;

  if (!resend) {
    // Dev fallback — vypíše odkaz do konzole místo reálného odeslání
    console.log(`[DEV] Ověřovací email pro ${email}: ${verifyUrl}`);
    return;
  }

  await resend.emails.send({
    from: "Connect <no-reply@connect-app.dev>",
    to: email,
    subject: "Ověřte svůj email",
    html: `
      <div style="font-family: sans-serif; max-width: 480px; margin: 0 auto;">
        <h2 style="color:#128b8c;">Vítejte v aplikaci Connect</h2>
        <p>Pro dokončení registrace prosím ověřte svůj email kliknutím na tlačítko níže.</p>
        <a href="${verifyUrl}" style="display:inline-block;padding:12px 24px;background:#19adad;color:#fff;border-radius:12px;text-decoration:none;">Ověřit email</a>
        <p style="color:#687285;font-size:12px;margin-top:24px;">Pokud jste se neregistrovali, tento email ignorujte.</p>
      </div>
    `
  });
}

export async function sendPasswordResetEmail(email: string, token: string) {
  const resetUrl = `${APP_URL}/reset-password?token=${token}`;
  if (!resend) {
    console.log(`[DEV] Reset hesla pro ${email}: ${resetUrl}`);
    return;
  }
  await resend.emails.send({
    from: "Connect <no-reply@connect-app.dev>",
    to: email,
    subject: "Obnovení hesla",
    html: `<p>Pro obnovení hesla klikněte <a href="${resetUrl}">zde</a>. Odkaz platí 1 hodinu.</p>`
  });
}
