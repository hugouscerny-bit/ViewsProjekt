// Jednoduchý rate limiter (pro produkci doporučeno nahradit Redis řešením,
// např. @upstash/ratelimit, zejména při běhu na více instancích).

interface Bucket {
  count: number;
  resetAt: number;
}

const buckets = new Map<string, Bucket>();

/**
 * Ověří, zda daný klíč (typicky IP + route) nepřekročil limit počtu požadavků.
 * @returns true pokud je požadavek povolen, false pokud je limit překročen
 */
export function rateLimit(key: string, limit: number, windowMs: number): boolean {
  const now = Date.now();
  const bucket = buckets.get(key);

  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }

  if (bucket.count >= limit) {
    return false;
  }

  bucket.count += 1;
  return true;
}

// Pravidelný úklid starých záznamů, aby mapa neutíkala do paměti
setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt < now) buckets.delete(key);
  }
}, 60_000);
