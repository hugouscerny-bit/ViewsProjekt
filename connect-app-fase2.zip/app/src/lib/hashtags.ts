// Extrahuje unikátní hashtagy z textu příspěvku, např. "#léto" nebo "#travel2024"
export function extractHashtags(text: string): string[] {
  const matches = text.match(/#[\p{L}0-9_]+/gu) ?? [];
  const unique = new Set(matches.map((tag) => tag.slice(1).toLowerCase()));
  return Array.from(unique);
}
