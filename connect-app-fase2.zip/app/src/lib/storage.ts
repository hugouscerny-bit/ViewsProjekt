import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { nanoid } from "nanoid";

const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif", "video/mp4", "video/webm", "audio/webm", "audio/mpeg"];
const MAX_SIZE_BYTES = 50 * 1024 * 1024; // 50 MB

export class UploadError extends Error {}

/**
 * Uloží nahraný soubor a vrátí veřejnou URL.
 * V produkci nahraďte voláním S3-kompatibilního úložiště (viz proměnné S3_* v .env).
 */
export async function saveUpload(file: File): Promise<string> {
  if (!ALLOWED_TYPES.includes(file.type)) {
    throw new UploadError("Nepodporovaný typ souboru.");
  }
  if (file.size > MAX_SIZE_BYTES) {
    throw new UploadError("Soubor je příliš velký (max. 50 MB).");
  }

  const bytes = Buffer.from(await file.arrayBuffer());
  const ext = file.type.split("/")[1] ?? "bin";
  const filename = `${nanoid(16)}.${ext}`;

  if (process.env.S3_BUCKET && process.env.S3_ENDPOINT) {
    return uploadToS3(bytes, filename, file.type);
  }

  // Lokální fallback (vhodné pro vývoj, ne pro produkční škálování)
  const uploadDir = path.join(process.cwd(), "public", "uploads");
  await mkdir(uploadDir, { recursive: true });
  await writeFile(path.join(uploadDir, filename), bytes);
  return `/uploads/${filename}`;
}

async function uploadToS3(bytes: Buffer, filename: string, contentType: string): Promise<string> {
  // Připraveno pro AWS SDK v3 / S3-kompatibilní služby (Cloudflare R2, MinIO...).
  // Instalace: npm install @aws-sdk/client-s3
  const { S3Client, PutObjectCommand } = await import("@aws-sdk/client-s3");
  const client = new S3Client({
    endpoint: process.env.S3_ENDPOINT,
    region: "auto",
    credentials: {
      accessKeyId: process.env.S3_ACCESS_KEY as string,
      secretAccessKey: process.env.S3_SECRET_KEY as string
    }
  });
  await client.send(
    new PutObjectCommand({
      Bucket: process.env.S3_BUCKET,
      Key: filename,
      Body: bytes,
      ContentType: contentType,
      ACL: "public-read"
    })
  );
  return `${process.env.S3_ENDPOINT}/${process.env.S3_BUCKET}/${filename}`;
}
