export default function ChatHome() {
  return (
    <main className="mx-auto max-w-md px-6 py-10 text-center">
      <div className="card">
        <h1 className="font-display text-xl font-bold">Zprávy</h1>
        <p className="mt-2 text-sm text-ink-500 dark:text-ink-300">
          Realtime chat (Socket.io) přidáme ve Fázi 3.
        </p>
      </div>
    </main>
  );
}
