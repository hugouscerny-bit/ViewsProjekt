"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { MapPin } from "lucide-react";

export default function LocationPermissionPage() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  function requestLocation() {
    setError(null);
    setLoading(true);

    if (!navigator.geolocation) {
      setError("Váš prohlížeč nepodporuje geolokaci.");
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        await fetch("/api/user/location", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          })
        });
        setLoading(false);
        router.push("/dating");
      },
      () => {
        setError("Poloha nebyla povolena. Bez ní nelze zobrazit uživatele ve vašem okolí.");
        setLoading(false);
      }
    );
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-6">
      <div className="card w-full max-w-md text-center animate-scale-in">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-turquoise-500/10 text-turquoise-600 dark:text-turquoise-300">
          <MapPin size={28} />
        </div>
        <h1 className="font-display text-2xl font-bold">Povolte polohu</h1>
        <p className="mt-2 text-sm text-ink-500 dark:text-ink-300">
          Polohu využíváme výhradně k zobrazení uživatelů ve vašem okolí v seznamovací sekci.
          Bez jejího povolení vám nemůžeme relevantní profily nabídnout.
        </p>

        {error && <p className="mt-4 text-sm text-red-500">{error}</p>}

        <button onClick={requestLocation} disabled={loading} className="btn-primary mt-6 w-full">
          {loading ? "Zjišťujeme polohu…" : "Povolit polohu"}
        </button>
        <button onClick={() => router.push("/app")} className="btn-secondary mt-3 w-full">
          Teď ne
        </button>
      </div>
    </main>
  );
}
