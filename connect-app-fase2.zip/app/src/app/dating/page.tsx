export default function DatingHome() {
  return (
    <main className="mx-auto max-w-md px-6 py-10 text-center">
      <div className="card">
        <h1 className="font-display text-xl font-bold">Seznamka</h1>
        <p className="mt-2 text-sm text-ink-500 dark:text-ink-300">
          Věk ověřen ✓ Swipe karty a matching přidáme ve Fázi 4.
        </p>
      </div>
    </main>
  );
}
