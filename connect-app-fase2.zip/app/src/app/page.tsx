import Link from "next/link";
import { MessageCircle, Heart, Users, Zap, Image as ImageIcon, Shield } from "lucide-react";
import { Logo } from "@/components/Logo";
import { ThemeToggle } from "@/components/ThemeToggle";

const FEATURES = [
  { icon: ImageIcon, title: "Příspěvky a Stories", desc: "Sdílej fotky, videa, Stories a Reels se svými sledujícími." },
  { icon: MessageCircle, title: "Chat v reálném čase", desc: "Zprávy, hlasovky a videa doručené okamžitě, s potvrzením přečtení." },
  { icon: Heart, title: "Seznamka", desc: "Objevuj lidi ve svém okolí, swipuj a poznávej se skrz Match." },
  { icon: Users, title: "Komunita", desc: "Sleduj, komentuj, lajkuj a objevuj trendy přes hashtagy." },
  { icon: Shield, title: "Bezpečí na prvním místě", desc: "Ověření věku, blokování, nahlašování a šifrovaná data." },
  { icon: Zap, title: "Bleskově rychlé", desc: "Optimalizováno pro mobil i desktop, funguje i offline jako PWA." }
];

export default function LandingPage() {
  return (
    <main className="relative min-h-screen overflow-hidden">
      {/* Ambientní pozadí */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute -top-40 left-1/4 h-96 w-96 rounded-full bg-turquoise-300/30 blur-3xl dark:bg-turquoise-500/20" />
        <div className="absolute top-1/3 -right-20 h-80 w-80 rounded-full bg-turquoise-200/40 blur-3xl dark:bg-turquoise-700/20" />
      </div>

      {/* Navigace */}
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-6">
        <Logo />
        <div className="flex items-center gap-3">
          <ThemeToggle />
          <Link href="/login" className="btn-secondary hidden sm:inline-flex">Přihlásit se</Link>
          <Link href="/register" className="btn-primary">Vytvořit účet</Link>
        </div>
      </header>

      {/* Hero */}
      <section className="mx-auto flex max-w-4xl flex-col items-center px-6 pb-20 pt-16 text-center animate-fade-in">
        <div className="mb-6 inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-sm text-turquoise-700 dark:text-turquoise-300">
          <span className="h-2 w-2 rounded-full bg-turquoise-500 animate-pulse" />
          Nová generace sociální sítě
        </div>
        <h1 className="font-display text-4xl font-extrabold leading-tight tracking-tight sm:text-6xl">
          Sdílej. Chatuj.
          <br />
          <span className="bg-gradient-to-r from-turquoise-400 to-turquoise-600 bg-clip-text text-transparent">
            Poznávej nové lidi.
          </span>
        </h1>
        <p className="mt-6 max-w-xl text-lg text-ink-500 dark:text-ink-300">
          Connect spojuje to nejlepší ze sociálních sítí, messengerů a seznamek do jedné
          elegantní aplikace. Jedno místo pro tvůj digitální život.
        </p>
        <div className="mt-10 flex flex-col gap-4 sm:flex-row">
          <Link href="/register" className="btn-primary text-base">Začít zdarma</Link>
          <Link href="/login" className="btn-secondary text-base">Už mám účet</Link>
        </div>
      </section>

      {/* Funkce */}
      <section className="mx-auto max-w-6xl px-6 pb-24">
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map(({ icon: Icon, title, desc }, i) => (
            <div
              key={title}
              className="card animate-scale-in transition-transform duration-300 hover:-translate-y-1"
              style={{ animationDelay: `${i * 60}ms` }}
            >
              <div className="mb-4 flex h-11 w-11 items-center justify-center rounded-xl bg-turquoise-500/10 text-turquoise-600 dark:text-turquoise-300">
                <Icon size={22} />
              </div>
              <h3 className="font-display text-lg font-bold">{title}</h3>
              <p className="mt-1.5 text-sm text-ink-500 dark:text-ink-300">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Patička */}
      <footer className="border-t border-ink-100 dark:border-white/10 px-6 py-8">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 text-sm text-ink-400 sm:flex-row">
          <span>&copy; {new Date().getFullYear()} Connect. Všechna práva vyhrazena.</span>
          <div className="flex gap-6">
            <Link href="/privacy" className="hover:text-turquoise-500">Ochrana osobních údajů</Link>
            <Link href="/terms" className="hover:text-turquoise-500">Obchodní podmínky</Link>
          </div>
        </div>
      </footer>
    </main>
  );
}
