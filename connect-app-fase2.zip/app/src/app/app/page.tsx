"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { Loader2 } from "lucide-react";
import { Logo } from "@/components/Logo";
import { ThemeToggle } from "@/components/ThemeToggle";
import { AppNav } from "@/components/AppNav";
import { CreatePost } from "@/components/feed/CreatePost";
import { PostCard } from "@/components/feed/PostCard";
import type { FeedPost } from "@/lib/types";

export default function AppHome() {
  const [posts, setPosts] = useState<FeedPost[]>([]);
  const [cursor, setCursor] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const sentinelRef = useRef<HTMLDivElement>(null);

  const loadPosts = useCallback(async (cursorParam: string | null) => {
    const url = cursorParam ? `/api/posts?cursor=${cursorParam}` : "/api/posts";
    const res = await fetch(url);
    const data = await res.json();
    setPosts((prev) => (cursorParam ? [...prev, ...data.posts] : data.posts));
    setCursor(data.nextCursor);
    setHasMore(!!data.nextCursor);
  }, []);

  useEffect(() => {
    loadPosts(null).finally(() => setLoading(false));
  }, [loadPosts]);

  // Nekonečné scrollování — dotáhne další příspěvky při přiblížení konce
  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;
    const observer = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && hasMore && !loadingMore) {
        setLoadingMore(true);
        loadPosts(cursor).finally(() => setLoadingMore(false));
      }
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, [cursor, hasMore, loadingMore, loadPosts]);

  return (
    <div className="flex flex-col-reverse sm:flex-row">
      <AppNav />
      <main className="mx-auto w-full max-w-2xl px-4 pb-24 pt-6 sm:pb-10">
        <header className="mb-6 flex items-center justify-between sm:hidden">
          <Logo />
          <ThemeToggle />
        </header>

        <div className="space-y-5">
          <CreatePost onCreated={(post) => setPosts((prev) => [post as FeedPost, ...prev])} />

          {loading ? (
            <div className="flex justify-center py-12"><Loader2 className="animate-spin text-turquoise-500" /></div>
          ) : posts.length === 0 ? (
            <div className="card text-center text-sm text-ink-500 dark:text-ink-300">
              Zatím tu nic není. Buď první, kdo přidá příspěvek!
            </div>
          ) : (
            posts.map((post) => <PostCard key={post.id} post={post} />)
          )}

          <div ref={sentinelRef} className="flex justify-center py-4">
            {loadingMore && <Loader2 className="animate-spin text-turquoise-500" />}
          </div>
        </div>
      </main>
    </div>
  );
}
