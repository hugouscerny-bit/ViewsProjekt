"use client";

import { useState, FormEvent } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Logo } from "@/components/Logo";
import { Eye, EyeOff, Mail, Chrome, Apple } from "lucide-react";

export default function RegisterPage() {
  const router = useRouter();
  const [form, setForm] = useState({ email: "", username: "", displayName: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Registrace se nezdařila.");
      setSuccess(true);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Něco se pokazilo.");
    } finally {
      setLoading(false);
    }
  }

  if (success) {
    return (
      <main className="flex min-h-screen items-center justify-center px-6">
        <div className="card max-w-md text-center animate-scale-in">
          <Mail className="mx-auto mb-4 text-turquoise-500" size={40} />
          <h1 className="font-display text-2xl font-bold">Zkontrolujte svůj email</h1>
          <p className="mt-2 text-ink-500 dark:text-ink-300">
            Poslali jsme vám ověřovací odkaz na <strong>{form.email}</strong>. Po ověření se budete moci přihlásit.
          </p>
          <Link href="/login" className="btn-primary mt-6 inline-flex">Zpět na přihlášení</Link>
        </div>
      </main>
    );
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-6 py-12">
      <div className="w-full max-w-md animate-fade-in">
        <div className="mb-8 flex justify-center"><Logo /></div>
        <div className="card">
          <h1 className="font-display text-2xl font-bold">Vytvořit účet</h1>
          <p className="mt-1 text-sm text-ink-500 dark:text-ink-300">Připoj se ke Connect zdarma.</p>

          <div className="mt-6 grid grid-cols-2 gap-3">
            <button type="button" className="btn-secondary" onClick={() => (window.location.href = "/api/auth/oauth/google")}>
              <Chrome size={18} className="mr-2" /> Google
            </button>
            <button type="button" className="btn-secondary" onClick={() => (window.location.href = "/api/auth/oauth/apple")}>
              <Apple size={18} className="mr-2" /> Apple
            </button>
          </div>

          <div className="my-6 flex items-center gap-3 text-xs text-ink-400">
            <div className="h-px flex-1 bg-ink-200 dark:bg-white/10" />
            NEBO EMAILEM
            <div className="h-px flex-1 bg-ink-200 dark:bg-white/10" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="text" required placeholder="Zobrazované jméno" className="input-field"
              value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })}
            />
            <input
              type="text" required placeholder="Uživatelské jméno" className="input-field"
              value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })}
            />
            <input
              type="email" required placeholder="Email" className="input-field"
              value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"} required placeholder="Heslo" className="input-field pr-11"
                value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
              />
              <button type="button" onClick={() => setShowPassword((s) => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-400">
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            <p className="text-xs text-ink-400">Alespoň 8 znaků, jedno velké písmeno a číslici.</p>

            {error && <p className="text-sm text-red-500">{error}</p>}

            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? "Vytváříme účet…" : "Vytvořit účet"}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-ink-500 dark:text-ink-300">
            Registrací souhlasíte s{" "}
            <Link href="/terms" className="text-turquoise-500 hover:underline">obchodními podmínkami</Link> a{" "}
            <Link href="/privacy" className="text-turquoise-500 hover:underline">zásadami ochrany osobních údajů</Link>.
          </p>
        </div>
        <p className="mt-6 text-center text-sm text-ink-500 dark:text-ink-300">
          Už máte účet? <Link href="/login" className="font-semibold text-turquoise-500 hover:underline">Přihlásit se</Link>
        </p>
      </div>
    </main>
  );
}
