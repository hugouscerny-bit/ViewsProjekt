"use client";

import { useState, FormEvent, Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Logo } from "@/components/Logo";
import { Eye, EyeOff, Chrome, Apple } from "lucide-react";

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const [form, setForm] = useState({ email: "", password: "" });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const verified = params.get("verified") === "1";

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Přihlášení se nezdařilo.");
      router.push(params.get("redirect") ?? "/app");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Něco se pokazilo.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-6 py-12">
      <div className="w-full max-w-md animate-fade-in">
        <div className="mb-8 flex justify-center"><Logo /></div>
        <div className="card">
          <h1 className="font-display text-2xl font-bold">Vítejte zpět</h1>
          <p className="mt-1 text-sm text-ink-500 dark:text-ink-300">Přihlaste se ke svému účtu.</p>

          {verified && (
            <p className="mt-4 rounded-xl bg-turquoise-500/10 px-4 py-2 text-sm text-turquoise-700 dark:text-turquoise-300">
              Email byl úspěšně ověřen. Nyní se můžete přihlásit.
            </p>
          )}

          <div className="mt-6 grid grid-cols-2 gap-3">
            <button type="button" className="btn-secondary" onClick={() => (window.location.href = "/api/auth/oauth/google")}>
              <Chrome size={18} className="mr-2" /> Google
            </button>
            <button type="button" className="btn-secondary" onClick={() => (window.location.href = "/api/auth/oauth/apple")}>
              <Apple size={18} className="mr-2" /> Apple
            </button>
          </div>

          <div className="my-6 flex items-center gap-3 text-xs text-ink-400">
            <div className="h-px flex-1 bg-ink-200 dark:bg-white/10" />
            NEBO EMAILEM
            <div className="h-px flex-1 bg-ink-200 dark:bg-white/10" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="email" required placeholder="Email" className="input-field"
              value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
            />
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"} required placeholder="Heslo" className="input-field pr-11"
                value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
              />
              <button type="button" onClick={() => setShowPassword((s) => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-ink-400">
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
            <div className="flex justify-end">
              <Link href="/forgot-password" className="text-sm text-turquoise-500 hover:underline">Zapomenuté heslo?</Link>
            </div>

            {error && <p className="text-sm text-red-500">{error}</p>}

            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? "Přihlašujeme…" : "Přihlásit se"}
            </button>
          </form>
        </div>
        <p className="mt-6 text-center text-sm text-ink-500 dark:text-ink-300">
          Nemáte účet? <Link href="/register" className="font-semibold text-turquoise-500 hover:underline">Zaregistrovat se</Link>
        </p>
      </div>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense>
      <LoginForm />
    </Suspense>
  );
}
