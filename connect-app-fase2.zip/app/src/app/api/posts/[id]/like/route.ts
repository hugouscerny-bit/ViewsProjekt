import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

// POST — přidá like, DELETE — odebere like (toggle na frontendu)
export async function POST(_req: NextRequest, { params }: { params: { id: string } }) {
  const auth = getCurrentUser();
  if (!auth) return NextResponse.json({ error: "Nejste přihlášeni." }, { status: 401 });

  const post = await prisma.post.findUnique({ where: { id: params.id }, select: { authorId: true } });
  if (!post) return NextResponse.json({ error: "Příspěvek nenalezen." }, { status: 404 });

  await prisma.like.upsert({
    where: { postId_userId: { postId: params.id, userId: auth.userId } },
    create: { postId: params.id, userId: auth.userId },
    update: {}
  });

  // Notifikace autorovi (pokud nelajkuje sám sobě)
  if (post.authorId !== auth.userId) {
    await prisma.notification.create({
      data: { type: "LIKE", recipientId: post.authorId, actorId: auth.userId, entityId: params.id }
    });
  }

  const count = await prisma.like.count({ where: { postId: params.id } });
  return NextResponse.json({ liked: true, count });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const auth = getCurrentUser();
  if (!auth) return NextResponse.json({ error: "Nejste přihlášeni." }, { status: 401 });

  await prisma.like.deleteMany({ where: { postId: params.id, userId: auth.userId } });
  const count = await prisma.like.count({ where: { postId: params.id } });
  return NextResponse.json({ liked: false, count });
}
