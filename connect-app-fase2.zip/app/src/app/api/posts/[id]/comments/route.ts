import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";

const commentSchema = z.object({
  text: z.string().min(1, "Komentář nemůže být prázdný.").max(1000),
  parentId: z.string().optional()
});

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const comments = await prisma.comment.findMany({
    where: { postId: params.id, parentId: null },
    orderBy: { createdAt: "asc" },
    include: {
      author: { select: { id: true, username: true, displayName: true, avatarUrl: true } },
      replies: {
        orderBy: { createdAt: "asc" },
        include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true } } }
      }
    }
  });
  return NextResponse.json({ comments });
}

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const auth = getCurrentUser();
  if (!auth) return NextResponse.json({ error: "Nejste přihlášeni." }, { status: 401 });

  if (!rateLimit(`comment:${auth.userId}`, 20, 60_000)) {
    return NextResponse.json({ error: "Příliš mnoho komentářů, zpomalte." }, { status: 429 });
  }

  const parsed = commentSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.errors[0]?.message ?? "Neplatná data." }, { status: 400 });
  }

  const post = await prisma.post.findUnique({ where: { id: params.id }, select: { authorId: true } });
  if (!post) return NextResponse.json({ error: "Příspěvek nenalezen." }, { status: 404 });

  const comment = await prisma.comment.create({
    data: { postId: params.id, authorId: auth.userId, text: parsed.data.text, parentId: parsed.data.parentId },
    include: { author: { select: { id: true, username: true, displayName: true, avatarUrl: true } } }
  });

  if (post.authorId !== auth.userId) {
    await prisma.notification.create({
      data: { type: "COMMENT", recipientId: post.authorId, actorId: auth.userId, entityId: params.id }
    });
  }

  return NextResponse.json({ comment }, { status: 201 });
}
