import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export async function GET(_req: NextRequest, { params }: { params: { id: string } }) {
  const post = await prisma.post.findUnique({
    where: { id: params.id },
    include: {
      author: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVerifiedBadge: true } },
      _count: { select: { likes: true, comments: true } }
    }
  });
  if (!post) return NextResponse.json({ error: "Příspěvek nenalezen." }, { status: 404 });
  return NextResponse.json({ post });
}

export async function DELETE(_req: NextRequest, { params }: { params: { id: string } }) {
  const auth = getCurrentUser();
  if (!auth) return NextResponse.json({ error: "Nejste přihlášeni." }, { status: 401 });

  const post = await prisma.post.findUnique({ where: { id: params.id } });
  if (!post) return NextResponse.json({ error: "Příspěvek nenalezen." }, { status: 404 });

  const isOwner = post.authorId === auth.userId;
  const isModerator = auth.role === "ADMIN" || auth.role === "MODERATOR";
  if (!isOwner && !isModerator) {
    return NextResponse.json({ error: "Nemáte oprávnění smazat tento příspěvek." }, { status: 403 });
  }

  await prisma.post.delete({ where: { id: params.id } });
  return NextResponse.json({ message: "Příspěvek smazán." });
}
