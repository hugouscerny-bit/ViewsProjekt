import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { extractHashtags } from "@/lib/hashtags";
import { rateLimit } from "@/lib/rate-limit";

const createPostSchema = z.object({
  caption: z.string().max(2200).optional(),
  mediaUrls: z.array(z.string().url()).max(10).default([]),
  mediaType: z.enum(["image", "video", "mixed"]).optional(),
  isReel: z.boolean().default(false)
});

// GET /api/posts?cursor=<id>&limit=10 — feed s kurzorovou paginací
export async function GET(req: NextRequest) {
  const auth = getCurrentUser();
  const cursor = req.nextUrl.searchParams.get("cursor");
  const limit = Math.min(Number(req.nextUrl.searchParams.get("limit")) || 10, 30);

  // Vyloučíme příspěvky uživatelů, kteří mě blokovali nebo které jsem zablokoval já
  let excludedUserIds: string[] = [];
  if (auth) {
    const blocks = await prisma.block.findMany({
      where: { OR: [{ blockerId: auth.userId }, { blockedId: auth.userId }] },
      select: { blockerId: true, blockedId: true }
    });
    excludedUserIds = blocks.map((b) => (b.blockerId === auth.userId ? b.blockedId : b.blockerId));
  }

  const posts = await prisma.post.findMany({
    where: { authorId: { notIn: excludedUserIds } },
    orderBy: { createdAt: "desc" },
    take: limit,
    ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
    include: {
      author: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVerifiedBadge: true } },
      _count: { select: { likes: true, comments: true } },
      likes: auth ? { where: { userId: auth.userId }, select: { id: true } } : false
    }
  });

  return NextResponse.json({
    posts: posts.map((p) => ({ ...p, likedByMe: auth ? p.likes.length > 0 : false, likes: undefined })),
    nextCursor: posts.length === limit ? posts[posts.length - 1].id : null
  });
}

// POST /api/posts — vytvoření nového příspěvku
export async function POST(req: NextRequest) {
  const auth = getCurrentUser();
  if (!auth) return NextResponse.json({ error: "Nejste přihlášeni." }, { status: 401 });

  if (!rateLimit(`post:${auth.userId}`, 10, 60_000)) {
    return NextResponse.json({ error: "Příliš mnoho příspěvků najednou, zkuste to za chvíli." }, { status: 429 });
  }

  const parsed = createPostSchema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.errors[0]?.message ?? "Neplatná data." }, { status: 400 });
  }

  const { caption, mediaUrls, mediaType, isReel } = parsed.data;
  if (!caption?.trim() && mediaUrls.length === 0) {
    return NextResponse.json({ error: "Příspěvek musí obsahovat text nebo médium." }, { status: 400 });
  }

  const hashtags = caption ? extractHashtags(caption) : [];

  const post = await prisma.post.create({
    data: {
      authorId: auth.userId,
      caption,
      mediaUrls,
      mediaType,
      isReel,
      hashtags: {
        connectOrCreate: hashtags.map((tag) => ({ where: { tag }, create: { tag } }))
      }
    },
    include: {
      author: { select: { id: true, username: true, displayName: true, avatarUrl: true, isVerifiedBadge: true } }
    }
  });

  return NextResponse.json({ post }, { status: 201 });
}
