import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export async function POST(_req: NextRequest, { params }: { params: { username: string } }) {
  const auth = getCurrentUser();
  if (!auth) return NextResponse.json({ error: "Nejste přihlášeni." }, { status: 401 });

  const target = await prisma.user.findUnique({ where: { username: params.username } });
  if (!target) return NextResponse.json({ error: "Uživatel nenalezen." }, { status: 404 });
  if (target.id === auth.userId) return NextResponse.json({ error: "Nemůžete sledovat sami sebe." }, { status: 400 });

  await prisma.follow.upsert({
    where: { followerId_followingId: { followerId: auth.userId, followingId: target.id } },
    create: { followerId: auth.userId, followingId: target.id },
    update: {}
  });

  await prisma.notification.create({
    data: { type: "FOLLOW", recipientId: target.id, actorId: auth.userId }
  });

  return NextResponse.json({ following: true });
}

export async function DELETE(_req: NextRequest, { params }: { params: { username: string } }) {
  const auth = getCurrentUser();
  if (!auth) return NextResponse.json({ error: "Nejste přihlášeni." }, { status: 401 });

  const target = await prisma.user.findUnique({ where: { username: params.username } });
  if (!target) return NextResponse.json({ error: "Uživatel nenalezen." }, { status: 404 });

  await prisma.follow.deleteMany({ where: { followerId: auth.userId, followingId: target.id } });
  return NextResponse.json({ following: false });
}
