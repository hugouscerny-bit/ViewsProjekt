import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

export async function GET(_req: NextRequest, { params }: { params: { username: string } }) {
  const auth = getCurrentUser();

  const user = await prisma.user.findUnique({
    where: { username: params.username },
    select: {
      id: true, username: true, displayName: true, avatarUrl: true, bio: true,
      city: true, isVerifiedBadge: true, isPrivate: true, createdAt: true,
      socialLinks: true, photos: { orderBy: { order: "asc" } },
      posts: {
        orderBy: { createdAt: "desc" },
        take: 24,
        select: { id: true, mediaUrls: true, mediaType: true, caption: true, createdAt: true, _count: { select: { likes: true, comments: true } } }
      },
      _count: { select: { posts: true, followedBy: true, following: true } }
    }
  });

  if (!user) return NextResponse.json({ error: "Uživatel nenalezen." }, { status: 404 });

  let isFollowing = false;
  let isBlocked = false;
  if (auth && auth.userId !== user.id) {
    const [follow, block] = await Promise.all([
      prisma.follow.findUnique({ where: { followerId_followingId: { followerId: auth.userId, followingId: user.id } } }),
      prisma.block.findUnique({ where: { blockerId_blockedId: { blockerId: auth.userId, blockedId: user.id } } })
    ]);
    isFollowing = !!follow;
    isBlocked = !!block;
  }

  return NextResponse.json({ user, isFollowing, isBlocked, isOwnProfile: auth?.userId === user.id });
}
