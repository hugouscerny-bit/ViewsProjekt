import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const auth = getCurrentUser();
  if (!auth) return NextResponse.json({ user: null }, { status: 401 });

  const user = await prisma.user.findUnique({
    where: { id: auth.userId },
    select: {
      id: true, username: true, displayName: true, avatarUrl: true,
      role: true, ageConfirmed: true, datingEnabled: true
    }
  });

  return NextResponse.json({ user });
}
