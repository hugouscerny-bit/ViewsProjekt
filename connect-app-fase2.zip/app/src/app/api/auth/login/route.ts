import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyPassword, signAccessToken, signRefreshToken, setAuthCookies } from "@/lib/auth";
import { loginSchema } from "@/lib/validation";
import { rateLimit } from "@/lib/rate-limit";
import bcrypt from "bcryptjs";

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for") ?? "unknown";
  // Ochrana proti brute-force útokům na heslo
  if (!rateLimit(`login:${ip}`, 10, 60_000)) {
    return NextResponse.json({ error: "Příliš mnoho pokusů o přihlášení. Zkuste to za chvíli." }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Neplatný email nebo heslo." }, { status: 400 });
  }

  const { email, password } = parsed.data;
  const user = await prisma.user.findUnique({ where: { email } });

  // Vždy provedeme "dummy" porovnání i když uživatel neexistuje, aby útočník
  // nemohl podle časování odpovědi zjistit, zda email v systému existuje.
  const hashToCompare = user?.passwordHash ?? "$2a$12$invalidsaltinvalidsaltinvalidsal.invalidhasheddummy";
  const passwordValid = await verifyPassword(password, hashToCompare);

  if (!user || !passwordValid || !user.passwordHash) {
    return NextResponse.json({ error: "Neplatný email nebo heslo." }, { status: 401 });
  }

  if (user.isBanned) {
    return NextResponse.json({ error: "Tento účet byl zablokován." }, { status: 403 });
  }

  if (!user.emailVerified) {
    return NextResponse.json({ error: "Nejprve ověřte svůj email." }, { status: 403 });
  }

  const payload = { userId: user.id, role: user.role };
  const accessToken = signAccessToken(payload);
  const refreshToken = signRefreshToken(payload);
  const refreshTokenHash = await bcrypt.hash(refreshToken, 10);

  await prisma.user.update({
    where: { id: user.id },
    data: { refreshTokenHash, lastLoginAt: new Date(), lastLoginIp: ip }
  });

  setAuthCookies(accessToken, refreshToken);

  return NextResponse.json({
    user: {
      id: user.id,
      email: user.email,
      username: user.username,
      displayName: user.displayName,
      avatarUrl: user.avatarUrl,
      ageConfirmed: user.ageConfirmed,
      role: user.role
    }
  });
}
