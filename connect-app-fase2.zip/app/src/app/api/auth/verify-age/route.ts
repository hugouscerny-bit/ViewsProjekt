import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { ageVerificationSchema } from "@/lib/validation";

function calculateAge(birthDate: Date): number {
  const diff = Date.now() - birthDate.getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
}

export async function POST(req: NextRequest) {
  const auth = getCurrentUser();
  if (!auth) {
    return NextResponse.json({ error: "Nejste přihlášeni." }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const parsed = ageVerificationSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Souhlas a datum narození jsou povinné." }, { status: 400 });
  }

  const birthDate = new Date(parsed.data.birthDate);
  const age = calculateAge(birthDate);

  if (age < 18) {
    return NextResponse.json({ error: "Do seznamovací sekce musíte mít alespoň 18 let." }, { status: 403 });
  }

  await prisma.user.update({
    where: { id: auth.userId },
    data: {
      birthDate,
      ageConfirmed: true,
      ageConsentAt: new Date(),
      datingEnabled: true
    }
  });

  const res = NextResponse.json({ message: "Věk ověřen." });
  // Cookie čtená middlewarem pro rychlou kontrolu bez dotazu do DB
  res.cookies.set("age_confirmed", "1", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 365
  });
  return res;
}
