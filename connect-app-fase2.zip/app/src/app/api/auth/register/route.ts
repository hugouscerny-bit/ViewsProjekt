import { NextRequest, NextResponse } from "next/server";
import { nanoid } from "nanoid";
import { prisma } from "@/lib/prisma";
import { hashPassword } from "@/lib/auth";
import { registerSchema } from "@/lib/validation";
import { rateLimit } from "@/lib/rate-limit";
import { sendVerificationEmail } from "@/lib/email";

export async function POST(req: NextRequest) {
  // Ochrana proti brute-force / spam registracím
  const ip = req.headers.get("x-forwarded-for") ?? "unknown";
  if (!rateLimit(`register:${ip}`, 5, 60_000)) {
    return NextResponse.json({ error: "Příliš mnoho pokusů, zkuste to za chvíli." }, { status: 429 });
  }

  const body = await req.json().catch(() => null);
  const parsed = registerSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.errors[0]?.message ?? "Neplatná data" }, { status: 400 });
  }

  const { email, username, password, displayName } = parsed.data;

  const existing = await prisma.user.findFirst({
    where: { OR: [{ email }, { username }] }
  });
  if (existing) {
    return NextResponse.json({ error: "Účet s tímto emailem nebo jménem již existuje." }, { status: 409 });
  }

  const passwordHash = await hashPassword(password);
  const emailVerifyToken = nanoid(32);

  const user = await prisma.user.create({
    data: {
      email,
      username,
      displayName,
      passwordHash,
      emailVerifyToken,
      emailVerifyExpiry: new Date(Date.now() + 1000 * 60 * 60 * 24) // 24h platnost
    }
  });

  await sendVerificationEmail(user.email, emailVerifyToken);

  return NextResponse.json(
    { message: "Registrace úspěšná. Zkontrolujte email pro ověření účtu.", userId: user.id },
    { status: 201 }
  );
}
