import { NextResponse } from "next/server";
import { clearAuthCookies, getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function POST() {
  const user = getCurrentUser();
  if (user) {
    // Zneplatníme refresh token v DB, aby nemohl být znovu použit
    await prisma.user.update({
      where: { id: user.userId },
      data: { refreshTokenHash: null }
    }).catch(() => null);
  }
  clearAuthCookies();
  return NextResponse.json({ message: "Odhlášení proběhlo úspěšně." });
}
