import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(req: NextRequest) {
  const token = req.nextUrl.searchParams.get("token");
  const appUrl = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

  if (!token) {
    return NextResponse.redirect(`${appUrl}/login?error=missing_token`);
  }

  const user = await prisma.user.findUnique({ where: { emailVerifyToken: token } });

  if (!user || !user.emailVerifyExpiry || user.emailVerifyExpiry < new Date()) {
    return NextResponse.redirect(`${appUrl}/login?error=invalid_or_expired_token`);
  }

  await prisma.user.update({
    where: { id: user.id },
    data: { emailVerified: true, emailVerifyToken: null, emailVerifyExpiry: null }
  });

  return NextResponse.redirect(`${appUrl}/login?verified=1`);
}
