import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";
import { verifyRefreshToken, signAccessToken, signRefreshToken, setAuthCookies, clearAuthCookies } from "@/lib/auth";

export async function POST() {
  const refreshToken = cookies().get("refresh_token")?.value;
  if (!refreshToken) {
    return NextResponse.json({ error: "Chybí refresh token." }, { status: 401 });
  }

  const payload = verifyRefreshToken(refreshToken);
  if (!payload) {
    clearAuthCookies();
    return NextResponse.json({ error: "Neplatný nebo expirovaný token." }, { status: 401 });
  }

  const user = await prisma.user.findUnique({ where: { id: payload.userId } });
  if (!user?.refreshTokenHash || !(await bcrypt.compare(refreshToken, user.refreshTokenHash))) {
    clearAuthCookies();
    return NextResponse.json({ error: "Token byl zneplatněn, přihlaste se znovu." }, { status: 401 });
  }

  // Token rotation — vydáme nový pár tokenů a starý znehodnotíme
  const newPayload = { userId: user.id, role: user.role };
  const newAccessToken = signAccessToken(newPayload);
  const newRefreshToken = signRefreshToken(newPayload);
  const newHash = await bcrypt.hash(newRefreshToken, 10);

  await prisma.user.update({ where: { id: user.id }, data: { refreshTokenHash: newHash } });
  setAuthCookies(newAccessToken, newRefreshToken);

  return NextResponse.json({ message: "Token obnoven." });
}
