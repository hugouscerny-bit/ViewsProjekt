import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

const schema = z.object({
  latitude: z.number().min(-90).max(90),
  longitude: z.number().min(-180).max(180)
});

export async function POST(req: NextRequest) {
  const auth = getCurrentUser();
  if (!auth) return NextResponse.json({ error: "Nejste přihlášeni." }, { status: 401 });

  const parsed = schema.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return NextResponse.json({ error: "Neplatné souřadnice." }, { status: 400 });

  await prisma.user.update({
    where: { id: auth.userId },
    data: {
      latitude: parsed.data.latitude,
      longitude: parsed.data.longitude,
      locationUpdatedAt: new Date()
    }
  });

  return NextResponse.json({ message: "Poloha uložena." });
}
