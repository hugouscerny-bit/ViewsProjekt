export default function TermsPage() {
  return (
    <main className="mx-auto max-w-2xl px-6 py-16">
      <h1 className="font-display text-3xl font-bold">Obchodní podmínky</h1>
      <p className="mt-4 text-ink-500 dark:text-ink-300">
        Podmínky užívání aplikace Connect, včetně pravidel pro seznamovací sekci (18+) a chování
        uživatelů. Kompletní právní text doplníme ve Fázi 7.
      </p>
    </main>
  );
}
