"use client";

import { useState, FormEvent } from "react";
import { useRouter } from "next/navigation";
import { ShieldCheck } from "lucide-react";

export default function AgeVerificationPage() {
  const router = useRouter();
  const [birthDate, setBirthDate] = useState("");
  const [consent, setConsent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (!consent) {
      setError("Pro pokračování musíte souhlasit s podmínkami.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/auth/verify-age", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ birthDate, consent })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Ověření se nezdařilo.");
      router.push("/dating");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Něco se pokazilo.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-6">
      <div className="card w-full max-w-md animate-scale-in">
        <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-turquoise-500/10 text-turquoise-600 dark:text-turquoise-300">
          <ShieldCheck size={28} />
        </div>
        <h1 className="text-center font-display text-2xl font-bold">Ověření věku</h1>
        <p className="mt-2 text-center text-sm text-ink-500 dark:text-ink-300">
          Seznamovací sekce je určena pouze pro osoby starší 18 let.
        </p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-5">
          <div>
            <label htmlFor="birthDate" className="mb-1.5 block text-sm font-medium">Datum narození</label>
            <input
              id="birthDate" type="date" required className="input-field"
              max={new Date().toISOString().split("T")[0]}
              value={birthDate} onChange={(e) => setBirthDate(e.target.value)}
            />
          </div>

          <label className="flex items-start gap-3 rounded-xl border border-ink-200 dark:border-white/15 bg-white/50 dark:bg-white/5 p-4 text-sm">
            <input
              type="checkbox" checked={consent} onChange={(e) => setConsent(e.target.checked)}
              className="mt-0.5 h-4 w-4 accent-turquoise-500"
            />
            <span>
              Vstupem do seznamovací části potvrzuji, že je mi minimálně 18 let, souhlasím se
              zpracováním údajů a používám aplikaci na vlastní odpovědnost.
            </span>
          </label>

          {error && <p className="text-sm text-red-500">{error}</p>}

          <button type="submit" disabled={loading || !consent} className="btn-primary w-full">
            {loading ? "Ověřujeme…" : "Potvrdit a pokračovat"}
          </button>
        </form>
      </div>
    </main>
  );
}
