"use client";

import { useEffect, useState, use } from "react";
import Image from "next/image";
import Link from "next/link";
import { BadgeCheck, MapPin, Grid3x3, Loader2 } from "lucide-react";
import { AppNav } from "@/components/AppNav";

interface ProfileData {
  user: {
    id: string; username: string; displayName: string; avatarUrl: string | null; bio: string | null;
    city: string | null; isVerifiedBadge: boolean;
    posts: { id: string; mediaUrls: string[]; mediaType: string | null }[];
    _count: { posts: number; followedBy: number; following: number };
  };
  isFollowing: boolean;
  isOwnProfile: boolean;
}

export default function ProfilePage({ params }: { params: Promise<{ username: string }> }) {
  const { username } = use(params);
  const [data, setData] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [followBusy, setFollowBusy] = useState(false);

  useEffect(() => {
    fetch(`/api/users/${username}`)
      .then((res) => res.json())
      .then(setData)
      .finally(() => setLoading(false));
  }, [username]);

  async function toggleFollow() {
    if (!data || followBusy) return;
    setFollowBusy(true);
    const method = data.isFollowing ? "DELETE" : "POST";
    const res = await fetch(`/api/users/${username}/follow`, { method });
    if (res.ok) {
      const result = await res.json();
      setData({
        ...data,
        isFollowing: result.following,
        user: { ...data.user, _count: { ...data.user._count, followedBy: data.user._count.followedBy + (result.following ? 1 : -1) } }
      });
    }
    setFollowBusy(false);
  }

  if (loading) {
    return <div className="flex min-h-screen items-center justify-center"><Loader2 className="animate-spin text-turquoise-500" /></div>;
  }

  if (!data) {
    return <div className="flex min-h-screen items-center justify-center text-ink-500">Uživatel nenalezen.</div>;
  }

  const { user, isFollowing, isOwnProfile } = data;

  return (
    <div className="flex flex-col-reverse sm:flex-row">
      <AppNav />
      <main className="mx-auto w-full max-w-2xl px-4 pb-24 pt-8 sm:pb-10">
        <div className="flex items-center gap-6">
          <div className="h-24 w-24 shrink-0 overflow-hidden rounded-full bg-turquoise-500/20 sm:h-28 sm:w-28">
            {user.avatarUrl && <Image src={user.avatarUrl} alt={user.displayName} width={112} height={112} className="h-full w-full object-cover" />}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h1 className="font-display text-xl font-bold">{user.displayName}</h1>
              {user.isVerifiedBadge && <BadgeCheck size={18} className="text-turquoise-500" />}
            </div>
            <p className="text-sm text-ink-400">@{user.username}</p>
            <div className="mt-3 flex gap-5 text-sm">
              <span><strong>{user._count.posts}</strong> příspěvků</span>
              <span><strong>{user._count.followedBy}</strong> sledujících</span>
              <span><strong>{user._count.following}</strong> sleduje</span>
            </div>
          </div>
        </div>

        {user.bio && <p className="mt-4 text-sm">{user.bio}</p>}
        {user.city && (
          <p className="mt-1 flex items-center gap-1 text-sm text-ink-400"><MapPin size={14} /> {user.city}</p>
        )}

        <div className="mt-5">
          {isOwnProfile ? (
            <Link href="/settings/profile" className="btn-secondary w-full sm:w-auto">Upravit profil</Link>
          ) : (
            <button onClick={toggleFollow} disabled={followBusy} className={isFollowing ? "btn-secondary" : "btn-primary"}>
              {isFollowing ? "Sledováno" : "Sledovat"}
            </button>
          )}
        </div>

        <div className="mt-8 flex items-center gap-2 border-t border-ink-100 pt-4 text-sm font-semibold dark:border-white/10">
          <Grid3x3 size={16} /> Příspěvky
        </div>
        <div className="mt-3 grid grid-cols-3 gap-1">
          {user.posts.map((post) => (
            <Link key={post.id} href={`/post/${post.id}`} className="relative aspect-square overflow-hidden rounded-lg bg-ink-100 dark:bg-white/5">
              {post.mediaUrls[0] && <Image src={post.mediaUrls[0]} alt="" fill className="object-cover" />}
            </Link>
          ))}
        </div>
        {user.posts.length === 0 && <p className="mt-6 text-center text-sm text-ink-400">Zatím žádné příspěvky.</p>}
      </main>
    </div>
  );
}
