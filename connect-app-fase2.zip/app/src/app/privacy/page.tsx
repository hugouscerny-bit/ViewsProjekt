export default function PrivacyPage() {
  return (
    <main className="mx-auto max-w-2xl px-6 py-16">
      <h1 className="font-display text-3xl font-bold">Zásady ochrany osobních údajů</h1>
      <p className="mt-4 text-ink-500 dark:text-ink-300">
        Tento dokument popisuje, jaké údaje o vás zpracováváme, proč a jak dlouho, v souladu s GDPR.
        Kompletní právní text doplníme ve Fázi 7 spolu s cookie lištou a nastavením soukromí.
      </p>
    </main>
  );
}
