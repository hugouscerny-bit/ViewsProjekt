// Samostatný Socket.io server pro realtime chat, online stav a notifikace.
// Běží odděleně od Next.js (Next API routy jsou bezstavové/serverless-friendly,
// zatímco WebSocket spojení potřebuje dlouhotrvající proces).

import { createServer } from "http";
import { Server } from "socket.io";
import jwt from "jsonwebtoken";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
const httpServer = createServer();

const io = new Server(httpServer, {
  cors: {
    origin: process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000",
    credentials: true
  }
});

interface AuthPayload {
  userId: string;
  role: string;
}

// Middleware: ověří JWT access token předaný při handshake
io.use((socket, next) => {
  try {
    const token = socket.handshake.auth?.token as string | undefined;
    if (!token) return next(new Error("Chybí autentizační token"));
    const payload = jwt.verify(token, process.env.JWT_ACCESS_SECRET as string) as AuthPayload;
    socket.data.userId = payload.userId;
    next();
  } catch {
    next(new Error("Neplatný token"));
  }
});

const onlineUsers = new Map<string, string>(); // userId -> socketId

io.on("connection", (socket) => {
  const userId = socket.data.userId as string;
  onlineUsers.set(userId, socket.id);
  socket.join(`user:${userId}`);
  io.emit("presence:update", { userId, online: true });

  // Připojení do konverzace (room)
  socket.on("conversation:join", (conversationId: string) => {
    socket.join(`conversation:${conversationId}`);
  });

  // Odeslání zprávy
  socket.on("message:send", async (data: { conversationId: string; text?: string; attachmentUrl?: string; attachmentType?: string }) => {
    const message = await prisma.message.create({
      data: {
        conversationId: data.conversationId,
        senderId: userId,
        text: data.text,
        attachmentUrl: data.attachmentUrl,
        attachmentType: data.attachmentType
      }
    });
    io.to(`conversation:${data.conversationId}`).emit("message:new", message);
  });

  // Indikátor psaní
  socket.on("typing:start", (conversationId: string) => {
    socket.to(`conversation:${conversationId}`).emit("typing:update", { userId, isTyping: true });
  });
  socket.on("typing:stop", (conversationId: string) => {
    socket.to(`conversation:${conversationId}`).emit("typing:update", { userId, isTyping: false });
  });

  // Potvrzení přečtení
  socket.on("message:read", async (data: { conversationId: string }) => {
    await prisma.conversationParticipant.updateMany({
      where: { conversationId: data.conversationId, userId },
      data: { lastReadAt: new Date() }
    });
    socket.to(`conversation:${data.conversationId}`).emit("message:read", { userId });
  });

  socket.on("disconnect", () => {
    onlineUsers.delete(userId);
    io.emit("presence:update", { userId, online: false });
  });
});

const PORT = process.env.SOCKET_PORT ?? 4000;
httpServer.listen(PORT, () => {
  console.log(`Socket.io server běží na portu ${PORT}`);
});
