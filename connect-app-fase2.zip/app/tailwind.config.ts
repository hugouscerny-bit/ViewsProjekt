import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        turquoise: {
          50: "#eefdfc",
          100: "#d4f7f5",
          200: "#aeeeec",
          300: "#78e0de",
          400: "#3dc9c8",
          500: "#19adad",
          600: "#128b8c",
          700: "#136f70",
          800: "#155a5a",
          900: "#154b4b",
          950: "#052b2c"
        },
        ink: {
          50: "#f6f7f8",
          100: "#eceef0",
          200: "#d5d9de",
          300: "#b1b9c2",
          400: "#8691a0",
          500: "#687285",
          600: "#535c6e",
          700: "#444b5a",
          800: "#3a3f4b",
          900: "#1a1c22",
          950: "#0a0b0d"
        }
      },
      fontFamily: {
        display: ["var(--font-display)", "sans-serif"],
        body: ["var(--font-body)", "sans-serif"]
      },
      borderRadius: {
        xl2: "1.25rem",
        xl3: "1.75rem"
      },
      backdropBlur: {
        xs: "2px"
      },
      boxShadow: {
        glass: "0 8px 32px 0 rgba(19, 111, 112, 0.15)",
        "glass-dark": "0 8px 32px 0 rgba(0, 0, 0, 0.4)"
      },
      keyframes: {
        "fade-in": { "0%": { opacity: "0", transform: "translateY(8px)" }, "100%": { opacity: "1", transform: "translateY(0)" } },
        "scale-in": { "0%": { opacity: "0", transform: "scale(0.96)" }, "100%": { opacity: "1", transform: "scale(1)" } }
      },
      animation: {
        "fade-in": "fade-in 0.5s ease-out",
        "scale-in": "scale-in 0.3s ease-out"
      }
    }
  },
  plugins: []
};

export default config;
